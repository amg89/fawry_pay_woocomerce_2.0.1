# myfawry_woocomerce
Fawry Pay woo-commerce plugin
### To install simply : 
1. download the zip file 
2. open wordpress[admin] plugins page
3. click add new 
4. click upload plugin, browse to the zipped file and choose it
